package br.edu.ifrn.cruds.dto;

public class AutocompleteDTO {
	
	private String label;
	
	private Integer valeu;
	
	

	public AutocompleteDTO(String label, Integer valeu) {
		super();
		this.label = label;
		this.valeu = valeu;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public Integer getValeu() {
		return valeu;
	}

	public void setValeu(Integer valeu) {
		this.valeu = valeu;
	}
	

}
