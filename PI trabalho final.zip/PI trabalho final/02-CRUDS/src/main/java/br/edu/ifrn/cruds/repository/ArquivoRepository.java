package br.edu.ifrn.cruds.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.edu.ifrn.cruds.dominio.Arquivo;

public interface ArquivoRepository extends JpaRepository<Arquivo, Long> {

}
