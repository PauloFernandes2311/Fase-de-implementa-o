package br.edu.ifrn.cruds.controladores;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.edu.ifrn.cruds.dominio.Usuario;
import br.edu.ifrn.cruds.repository.UsuarioRepository;

@Controller
@RequestMapping("/usuarios")
public class BuscaUsuarioController {
	

	@Autowired
	private UsuarioRepository usuarioRepository;

	@GetMapping("/busca")
	public String entrarBuscar() {
		return "usuario/busca";

	}
   @Transactional(readOnly = true)
	@GetMapping("/buscar")
	public String buscar(@RequestParam(name = "nome", required = false) String nome,
			@RequestParam(name = "email", required = false) String email,
			@RequestParam(name = "mostrarTodosDados", required = false) Boolean mostrarTodosDados , HttpSession sessao , ModelMap model) {
         
		List<Usuario> usuariosEncontrados = usuarioRepository.findByEmailAndNome(email, nome);
		
		model.addAttribute("usuariosEncontrados", usuariosEncontrados);
	
		
		if (mostrarTodosDados != null) {
			model.addAttribute("mostrarTodosDados" , true); 
			
		}
		
		return "usuario/busca";

	}
	
	 @GetMapping("/remover/{id}")
	public String remover( 
			@PathVariable ("id") Integer idUsuario, HttpSession sessao,
			RedirectAttributes attr) {
		 
		
		usuarioRepository.deleteById(idUsuario);	
			attr.addAttribute("msgSucesso","Usuário removido com sucesso !");
			
	
		 return "redirect:/usuarios/buscar";
	}
		

}
